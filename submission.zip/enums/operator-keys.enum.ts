
export enum OperatorKeys {
  PLUS = '+',
  MINUS = '-',
  MULT = '*',
  DIV = '/',
  SQRT = '√'
}
